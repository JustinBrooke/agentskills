import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [currentQuote, setCurrentQuote] = useState(0);
  const [, setLocation] = useLocation();

  const quotes = [
    "/andrew-ng-ai-agent-quote.jpg",
    "/bill-gates-ai-agent-quote.jpg",
    "/satya-nadella-ai-agent-quote.jpg",
    "/jeff-bezos-ai-agent-quote.jpg",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('https://app.convertkit.com/integrations/unbounce/8687467/webhook?api_key=SJimEg4LnwAgBFwP9z30gg', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
        }),
      });

      if (response.ok) {
        // Redirect immediately to thank you page
        setLocation('/thanks');
      } else {
        console.error('Failed to submit email');
        alert('Something went wrong. Please try again.');
      }
    } catch (error) {
      console.error('Error submitting email:', error);
      alert('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Authority Quotes Section - Rotating Carousel */}
      <div className="container py-12">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="relative aspect-[16/9] overflow-hidden rounded-lg">
            <img 
              src={quotes[currentQuote]} 
              alt="Authority quote on AI agents"
              className="w-full h-full object-cover transition-opacity duration-1000"
            />
          </div>
          
          {/* Navigation Dots */}
          <div className="flex justify-center gap-3">
            {quotes.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentQuote(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                  currentQuote === index 
                    ? 'bg-primary' 
                    : 'bg-white hover:bg-white/70'
                }`}
                aria-label={`Go to quote ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="container pb-12 md:pb-20">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h1 className="text-4xl md:text-6xl lg:text-7xl tracking-tight">
            The Dawn of Agentic Commerce
          </h1>
          <p className="text-xl md:text-2xl text-primary">
            Get ready for the most important change to business since the invention of the Internet.
          </p>
          <div className="pt-8 space-y-4 text-lg md:text-xl text-foreground/90 text-left">
            <p>
              Remember when the internet made millionaires out of their garages and bedrooms?
            </p>
            <p className="font-bold">
              This is bigger.
            </p>
            <p>
              Agentic commerce is a full restructuring of the Internet in the way things are bought and sold online. Except this time, you won't need venture capital, hiring outsourcers, or create massive amounts of content.
            </p>
            <p className="font-bold text-primary">
              Just you.
            </p>
            <p className="font-bold text-primary">
              Your kitchen table.
            </p>
            <p className="font-bold text-primary">
              And an unfair advantage.
            </p>
          </div>
        </div>
      </div>

      {/* Body Copy Section */}
      <div className="container">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="space-y-6">
            <p className="text-lg md:text-xl">
              Imagine:
            </p>
          </div>

          <div className="space-y-4 text-lg">
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>Your calendar managed, your emails handled, your bookkeeping done</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>Customer service that never sleeps</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>Sales outreach running 24/7</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>Content creation, research, data entry—all handled</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p className="font-bold text-primary">You focus ONLY on the $1,000/hour work</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>Your profit margins stay at 70-80% (not 30-40%)</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-white font-bold">•</span>
              <p>You're present for dinner. For soccer games. For life.</p>
            </div>
          </div>

          <div className="text-center space-y-4 pt-8">
          <div className="text-xl text-center space-y-2">
            <p>This isn't science fiction.</p>
            <p>This is 2026.</p>
          </div>
          </div>
        </div>
      </div>

      {/* Urgency Section */}
      <div className="container py-20 border-t border-border">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl md:text-4xl font-bold">
            But the window is closing...
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground">
            Early adopters are already automating their day and selling agents for $5k - $15k. The question isn't IF this happens—it's whether you'll be early or late (again).
          </p>
        </div>
      </div>

      {/* Coming Soon Opt-in */}
      <div className="container pb-20 border-t border-border">
        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-primary/50 bg-white">
            <CardHeader className="text-center space-y-4">
                <CardTitle className="text-4xl md:text-5xl font-bold tracking-wider text-black">
                  COMING SOON
                </CardTitle>
                <CardDescription className="text-lg text-black">
                  Be the first to know when we launch
                </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-12 text-lg bg-gray-100 border-gray-300 text-black placeholder:text-gray-500"
                  />
                  <Button
                    type="submit"
                    className="w-full min-h-12 h-auto py-3 text-lg font-bold whitespace-normal"
                    size="lg"
                  >
                    YES! Give Me One of The First 500 Spots
                  </Button>
                </form>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="container pb-20 border-t border-border">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Get these bonuses when you join FOR FREE today...
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-border bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-2xl font-bold">
                  MASTERCLASS
                </CardTitle>
                <CardDescription className="text-lg pt-2">
                  How to Come Up With AI Agent Ideas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Learn the framework for identifying high-value automation opportunities in your business that AI agents can solve.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-2xl font-bold">
                  MASTERCLASS
                </CardTitle>
                <CardDescription className="text-lg pt-2">
                  Zero to Hero: Building Your First Agent
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Step-by-step walkthrough of building your first AI agent from scratch, no coding required.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-2xl font-bold">
                  CASE STUDIES
                </CardTitle>
                <CardDescription className="text-lg pt-2">
                  Real Stories of Automation Success
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  See how others have already automated their day and are selling agents for thousands of dollars.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="container py-12 border-t border-border">
        <div className="text-center text-muted-foreground">
          <p>© 2025 AgentSkills.ai - All rights reserved</p>
        </div>
      </div>
    </div>
  );
}

