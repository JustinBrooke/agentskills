import { Button } from "@/components/ui/button";

export default function MindStudioWorkshop() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* $100 Bill Hero */}
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <img 
            src="/Usdollar100front.jpg" 
            alt="$100 Savings" 
            className="w-full max-w-2xl mx-auto"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-4xl mx-auto pb-20 space-y-16">
        
        {/* Headline */}
        <div className="text-center space-y-6">
          <h1 className="text-4xl md:text-6xl leading-tight">
            Build Your First AI Agent in 4 Hours<br />
            <span className="text-primary text-2xl md:text-3xl">(Even if You Can't Code)</span>
          </h1>
          <p className="text-2xl md:text-3xl text-muted-foreground italic">
            🤖 Yesterday I Built an Agent That Writes My Newsletters, Books My Meetings, and Answers Customer Questions... All for $10/Month
          </p>
        </div>

        {/* Opening Copy */}
        <div className="space-y-6 text-lg text-left">
          <p className="text-xl">Dear Future Agent Builder,</p>
          
          <p>Sam Altman just said 95% of marketing work will be done by AI agents.</p>
          
          <p>Not "might be." Not "could be."</p>
          
          <p><strong>WILL BE.</strong></p>
          
          <p>The internet is being restructured right now. Google and Stripe are building the protocols. The infrastructure is going live.</p>
          
          <p>And you have two choices:</p>
          
          <p className="pl-8">1. Keep doing everything manually and watch your competitors automate past you.</p>
          <p className="pl-8">2. Build your own AI agents and join the new economy.</p>
          
          <p>Here's the thing...</p>
          
          <p>Everyone thinks you need to be a programmer to build AI agents.</p>
          
          <p><strong className="text-primary">You don't.</strong></p>
          
          <p>I'm not a programmer. Never have been. But I've built 12 AI agents in the last 30 days using a tool called MindStudio.</p>
          
          <p>Cost? <strong className="text-primary">$10/month.</strong></p>
          
          <p>No APIs to configure. No webhooks to debug. No prompt engineering degree required.</p>
          
          <p>Just drag, drop, and deploy.</p>
        </div>

        {/* Visual Proof */}
        <div className="border-t border-b border-border py-12 space-y-6">
          <h2 className="text-3xl font-bold text-center">Here's What I Built Last Week With MindStudio</h2>
          <div className="space-y-4 text-lg">
            <p>✅ A newsletter writing agent that researches topics, writes drafts, and schedules sends</p>
            <p>✅ A lead qualification agent that books meetings only with qualified prospects</p>
            <p>✅ A customer support agent that answers 80% of questions without me</p>
            <p>✅ A content repurposing agent that turns one blog post into 20 social posts</p>
            <p>✅ An ad prediction agent that scores creative before I spend money testing</p>
          </div>
          <p className="text-xl text-center pt-6">Total time to build all 5? <strong className="text-primary">About 6 hours.</strong></p>
          <p className="text-center text-muted-foreground">Total cost? <strong>$10/month.</strong></p>
        </div>

        {/* Workshop Agenda */}
        <div className="space-y-8">
          <h2 className="text-4xl font-bold text-center">Here's The Agenda for Our Virtual Workshop</h2>
          
          <div className="space-y-8">
            {/* Session 1 */}
            <div className="space-y-3">
              <div className="flex items-baseline gap-4">
                <span className="text-primary font-bold text-2xl">10:00am EST</span>
                <h3 className="text-2xl font-bold">The Agent Opportunity (Why Now?)</h3>
              </div>
              <p className="text-lg text-muted-foreground pl-32">
                The infrastructure is being built RIGHT NOW by Google, Stripe, and OpenAI. Early adopters are already selling agents for $5k-$15k. You'll see the market data, the protocols being launched, and why this window won't stay open forever.
              </p>
            </div>

            {/* Session 2 */}
            <div className="space-y-3">
              <div className="flex items-baseline gap-4">
                <span className="text-primary font-bold text-2xl">10:30am EST</span>
                <h3 className="text-2xl font-bold">Your First Agent (Live Build)</h3>
              </div>
              <p className="text-lg text-muted-foreground pl-32">
                We're building a working AI agent together. You'll follow along step-by-step in MindStudio and walk away with a functioning agent that actually does real work. No theory. No slides. Just building.
              </p>
            </div>

            {/* Session 3 */}
            <div className="space-y-3">
              <div className="flex items-baseline gap-4">
                <span className="text-primary font-bold text-2xl">12:00pm EST</span>
                <h3 className="text-2xl font-bold">Networking Lunch</h3>
              </div>
              <p className="text-lg text-muted-foreground pl-32">
                You can eat your sandwich anytime, but during this lunch hour you need to make friends. Relationships are the biggest secret. Take everything away from me, but because of my relationships I can make a few phone calls and get it all back. DON'T WASTE THIS TIME!!!
              </p>
            </div>

            {/* Session 4 */}
            <div className="space-y-3">
              <div className="flex items-baseline gap-4">
                <span className="text-primary font-bold text-2xl">1:00pm EST</span>
                <h3 className="text-2xl font-bold">The 3 Agent Business Models</h3>
              </div>
              <p className="text-lg text-muted-foreground pl-32">
                There are 3 ways to make money with agents: 1) Use them in your business to 10x productivity, 2) Sell them to clients for $5k-$15k each, 3) Build a SaaS and charge monthly. I'll show you real examples of each and help you pick your path.
              </p>
            </div>

            {/* Session 5 */}
            <div className="space-y-3">
              <div className="flex items-baseline gap-4">
                <span className="text-primary font-bold text-2xl">1:30pm EST</span>
                <h3 className="text-2xl font-bold">Advanced Agent Workflows</h3>
              </div>
              <p className="text-lg text-muted-foreground pl-32">
                Now that you've built your first agent, let's make it smarter. You'll learn how to chain multiple agents together, connect them to your data, and automate complex workflows that used to require entire teams.
              </p>
            </div>
          </div>
        </div>

        {/* Value Proposition */}
        <div className="border-t border-border pt-12 space-y-6 text-lg">
          <h2 className="text-3xl font-bold text-center">What Would 10x Productivity Do For You?</h2>
          
          <p>Would it free you up to actually go get more clients? More time for family?</p>
          
          <p>I don't know what you do in your free time, I just know you want more of it.</p>
          
          <p>With AI agents, you will finish earlier and do more.</p>
          
          <p><strong>Imagine actually finishing your to-do lists!</strong></p>
          
          <p>If all you got out of this workshop was one working agent that saved you 10 hours per week, it would be worth at least $2,000.</p>
          
          <p>You're going to learn how to build multiple agents that automate your entire day.</p>
          
          <p>While I think $997 would be a fair price, I'm not even charging half that...</p>
          
          <p className="text-2xl font-bold text-primary text-center py-6">
            You're getting in for only $149 (because you saved $100)
          </p>
          
          <p className="text-center text-muted-foreground">Regular price is $249, but you claimed your new subscriber discount.</p>
        </div>

        {/* What You're Getting */}
        <div className="border-t border-border pt-12 space-y-6">
          <h2 className="text-3xl font-bold text-center">What You're Getting</h2>
          <div className="space-y-4 text-lg">
            <p>✅ <strong>4-hour LIVE virtual workshop on Zoom</strong> (November 6th, 10am-2pm EST)</p>
            <p>✅ <strong>Follow-along agent building</strong> - You'll build your first agent WITH me during the workshop</p>
            <p>✅ <strong>Live Q&A after every session</strong> - Ask me anything, I'll even share screens to help you personally</p>
            <p>✅ <strong>MindStudio templates</strong> - Copy my proven agent templates and customize them for your business</p>
            <p>✅ <strong>Workshop recordings</strong> - Sent via email 3-5 days after the event</p>
            <p>✅ <strong>Private community access</strong> - Network with other agent builders</p>
            <p>✅ <strong>30-day money-back guarantee</strong> - If you don't build at least one working agent, I'll refund you</p>
          </div>
        </div>

        {/* Instructor Bio */}
        <div className="border-t border-border pt-12 space-y-6">
          <h2 className="text-3xl font-bold text-center">Meet Your Instructor</h2>
          <div className="space-y-4 text-lg">
            <p><strong>Justin Brooke</strong> started in 2007 with just $60 in an Adwords account and turned it into 6 figures. Then opened a digital ad agency and grew it to 7 figures.</p>
            
            <p>For the last 5 years he's coached thousands of ad buyers within AdSkills from beginner to elite, leading them on to build their own 6 and 7 figure agencies.</p>
            
            <p>Justin mastered the craft of copywriting while working with the BILLION dollar publishing giant, Agora, as a Senior Media Buyer. His campaigns have generated over <strong>$400,000 per day</strong>, with more than <strong>1 million clicks per day</strong> and <strong>10,000+ leads per day</strong>.</p>
            
            <p>He's worked with industry legends like Dan Kennedy, Russell Brunson, and Ryan Deiss, and has trained tens of thousands of businesses in digital marketing.</p>
            
            <p>Now he's building AI agents to automate his entire marketing operation - and he wants to show you how to do the same.</p>
          </div>
        </div>

        {/* Social Proof */}
        <div className="border-t border-border pt-12 space-y-8">
          <h2 className="text-3xl font-bold text-center">Here's What Past Students Have To Say...</h2>
          
          <div className="space-y-6">
            <div className="border-l-4 border-primary pl-6 py-2">
              <p className="text-lg italic mb-2">"Within 6 months of completing the AdSkills training, I was earning $100,000 annually as a solo media buyer... I've found no community and no online resources that come close to matching the skills, talent, and knowledge of AdSkills."</p>
              <p className="font-bold">– Nate Smoyer</p>
            </div>
            
            <div className="border-l-4 border-primary pl-6 py-2">
              <p className="text-lg italic mb-2">"Thanks to what I've learned from AdSkills I'm now one of the top ad guys in my space. I'm even getting asked to speak on podcasts now because of the reputation from my results. And I owe a lot of that to AdSkills."</p>
              <p className="font-bold">– Jason Stogsdill</p>
            </div>
            
            <div className="border-l-4 border-primary pl-6 py-2">
              <p className="text-lg italic mb-2">"Everything put out by AdSkills flat out works and you're crazy if you aren't investing in yourself and your business with these courses. In 10 years, I've never gone through course after course from one person that produces results like I get with AdSkills."</p>
              <p className="font-bold">– Rory Stern</p>
            </div>
          </div>
        </div>

        {/* Warning */}
        <div className="border-t border-border pt-12 space-y-6 bg-card/30 p-8 rounded-lg">
          <h2 className="text-3xl font-bold text-center text-primary">WARNING! This Is Not Get Rich Quick</h2>
          <div className="space-y-4 text-lg">
            <p>If you're hoping this is copy/paste automated faceless riches...</p>
            <p><strong>You've got the wrong guy!</strong></p>
            <p>This workshop is for people who want to BUILD. Who want to learn. Who want to automate their business the right way.</p>
            <p>You'll need to show up, pay attention, and actually build your agent during the workshop.</p>
            <p>But if you do the work, you'll walk away with a real, functioning AI agent that does real work in your business.</p>
          </div>
        </div>

        {/* Two Options Close */}
        <div className="border-t border-border pt-12 space-y-8 text-center">
          <h2 className="text-3xl font-bold">Here's Your Chance to Get Ahead</h2>
          
          <div className="space-y-6 text-lg">
            <p>Maybe you're already crushing it?</p>
            <p>Maybe you have a big team and millions in revenue??</p>
            <p>If that's the case, then you do not need this workshop. You can just exit out of this page and go back to your life. This isn't for you.</p>
            <p>But if you're still a one-person shop, or have less than 5 employees, then this workshop is going to make you feel like you have 10 employees.</p>
          </div>
          
          <div className="space-y-4 text-xl py-8">
            <p><strong>OPTION A:</strong> Hit the back button and your life stays the same.</p>
            <p><strong>OPTION B:</strong> Hit the order button, join us, and become an AI-powered productivity machine!</p>
            <p className="text-muted-foreground">Only you know what you need...</p>
          </div>

          {/* CTA Button */}
          <div className="py-8">
            <Button 
              size="lg" 
              className="text-2xl px-12 py-8 bg-primary hover:bg-primary/90 text-black font-bold"
              onClick={() => window.location.href = 'https://buy.stripe.com/your-payment-link'}
            >
              YES! Get Me In For $149
            </Button>
            <p className="text-sm text-muted-foreground mt-4">Workshop on November 6th, 10am-2pm EST</p>
            <p className="text-sm text-muted-foreground">Limited to 100 spots</p>
          </div>
        </div>

        {/* Bonus */}
        <div className="border-t border-border pt-12 space-y-6 bg-primary/10 p-8 rounded-lg">
          <div className="text-center">
            <span className="text-6xl">🎁</span>
            <h2 className="text-3xl font-bold mt-4">NEW! Bonus Course</h2>
            <h3 className="text-2xl font-bold text-primary mt-2">CloneU HeyGen Video Cloning</h3>
          </div>
          <div className="space-y-4 text-lg">
            <p>Now you can create videos in minutes without ever stepping in front of a camera. Create a digital version of yourself that delivers your message authentically—without buying a whole recording studio.</p>
            
            <p>Build professional videos for social media, podcasts, online courses, YouTube, Reels, and more—even if you're a total beginner. Do the work of a whole marketing team with 1 person.</p>
            
            <p>Learn a proven scripting formula and step-by-step process to ensure your videos look natural and connect with your audience.</p>
            
            <p className="text-center font-bold text-xl pt-4">(Value: $249)</p>
          </div>
        </div>

        {/* FAQ / Support */}
        <div className="border-t border-border pt-12 space-y-6 text-center">
          <h2 className="text-3xl font-bold">Have Questions? Need Help?</h2>
          <p className="text-lg">24 hour email support - <a href="mailto:support@adskills.com" className="text-primary hover:underline">support@adskills.com</a></p>
          <p className="text-lg">Phone - <a href="tel:8007582751" className="text-primary hover:underline">800 758 2751</a></p>
        </div>

        {/* Final CTA */}
        <div className="text-center py-12">
          <p className="text-2xl font-bold mb-6">We Start Building @ 10am EST on November 6th</p>
          <Button 
            size="lg" 
            className="text-2xl px-12 py-8 bg-primary hover:bg-primary/90 text-black font-bold"
            onClick={() => window.location.href = 'https://buy.stripe.com/your-payment-link'}
          >
            Claim Your Spot For $149
          </Button>
          <p className="text-sm text-muted-foreground mt-4">**Recordings will be sent via email to all workshop customers 3-5 days after the event</p>
        </div>

      </div>

      {/* Footer */}
      <div className="border-t border-border py-12 bg-card/30">
        <div className="container max-w-4xl mx-auto text-center space-y-4 text-sm text-muted-foreground">
          <p>© 2025 AgentSkills.ai - All Rights Reserved</p>
          <div className="flex justify-center gap-6">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Refund Policy</a>
            <a href="#" className="hover:text-primary">Terms</a>
            <a href="#" className="hover:text-primary">Support</a>
          </div>
          <p className="text-xs pt-4">Disclaimer: Results mentioned are not typical and are the result of years of training and experience. Individual results will vary. This is not a get-rich-quick program.</p>
        </div>
      </div>
    </div>
  );
}

