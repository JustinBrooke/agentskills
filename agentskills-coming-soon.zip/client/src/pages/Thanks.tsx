import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Thanks() {
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
      <div className="container py-20">
        <div className="max-w-3xl mx-auto text-center space-y-12">
          {/* Headline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl tracking-tight">
            Thank You! You're on the waitlist...
          </h1>

          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-primary">
            Check your email for an email with the subject 'The Dawn of Agentic Commerce [DAY ZERO]'
          </p>

          {/* Divider */}
          <div className="border-t border-border my-12"></div>

          {/* Coupon Teaser Section */}
          <div className="space-y-8">
            <h2 className="text-3xl md:text-4xl tracking-tight">
              Claim Your New Subscriber $100 Off Coupon Before You Leave This Page.
            </h2>

            <Link href="/mindstudio-workshop">
              <Button 
                size="lg" 
                className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 text-black font-bold"
              >
                Get $100 off Here
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

